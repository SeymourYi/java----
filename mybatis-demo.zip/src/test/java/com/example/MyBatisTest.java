package com.example;

import com.example.mapper.UserMapper;
import com.example.model.User;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class MyBatisTest {

    @Test
    public void testFindAll() {
        try (SqlSession session = MyBatisConfig.getSqlSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            List<User> users = userMapper.findAll();
            assertNotNull(users);
            assertFalse(users.isEmpty());
        }
    }

    @Test
    public void testFindByConditions() {
        try (SqlSession session = MyBatisConfig.getSqlSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            User user = new User();
            user.setName("John Doe");

            List<User> users = userMapper.findByConditions(user);
            assertNotNull(users);
        }
    }

    @Test
    public void testDeleteByIds() {
        try (SqlSession session = MyBatisConfig.getSqlSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            int[] ids = {1, 2, 3};
            int result = userMapper.deleteByIds(ids);
            assertEquals(3, result);
            session.commit();
        }
    }
}