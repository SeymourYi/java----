package com.example.mapper;

import com.example.model.User;
import java.util.List;

public interface UserMapper {
    List<User> findAll();

    List<User> findByConditions(User user);

    int deleteByIds(int[] ids);
}