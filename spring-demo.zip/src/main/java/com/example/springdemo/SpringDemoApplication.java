package com.example.springdemo;

import com.example.springdemo.config.AppConfig;
import com.example.springdemo.model.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringDemoApplication {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        // 测试 User 是否注入成功
        User user = context.getBean(User.class);
        System.out.println("User: " + user.getName() + ", " + user.getAge() + ", " + user.getEmail());
        // 测试 Druid 数据源是否配置成功等操作可以在这里进行
    }
}