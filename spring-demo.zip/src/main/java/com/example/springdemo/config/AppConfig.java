package com.example.springdemo.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.springdemo.model.User;

@Configuration
public class AppConfig {

    @Bean
    public User user() {
        User user = new User();
        user.setName("John");
        user.setAge(30);
        user.setEmail("john@example.com");
        return user;
    }

    @Bean
    public DruidDataSource dataSource() {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl("jdbc:mysql://localhost:3306/testdb");
        dataSource.setUsername("root");
        dataSource.setPassword("password");
        // 其他 Druid 数据源相关配置可以在这里设置
        return dataSource;
    }
}