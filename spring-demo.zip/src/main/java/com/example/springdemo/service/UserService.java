package com.example.springdemo.service;

public class UserService {
}
